Commands
========

local commands
--------------
# must be defined but don't have any server implementation
default
generate
-h
--help
help
migrate
update
version

done
----
configure accountkey
new
deploy
develop
download

todo
----
add
configure *
functions
jssdk
list
logs
releases
rollback
symbols
triggers
